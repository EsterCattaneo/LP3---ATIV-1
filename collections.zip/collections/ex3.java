package exercicios.array.collections;
import java.util.Vector;

public class ex3 {

	public static void main(String[] args) {
		Vector<Integer> vector = new Vector<>();
        vector.add(7);
        vector.add(11);
        vector.add(21);
        vector.add(28);

        System.out.println("Vector: " + vector);  // Exibe o vetor: [10, 20, 30]
	}

}
