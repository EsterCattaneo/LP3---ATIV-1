package exercicios.array.collections;
import java.util.ArrayList;
import java.util.List;


public class ex0 {

	public static void main(String[] args) {
		List<String> cidades = new ArrayList<>();  // Cria uma lista vazia de Strings
        cidades.add("Campinas");  
        cidades.add("Rio de Janeiro");  
        cidades.add("Porto Franco"); 

        System.out.println(cidades); 
	}

}
